Author: Ryan Kahil

About Encryption Program: This is a small program that is run on the command line and creates a small .pem file of an encrypted phrase. This primarily deals with the practice of Encrypting, passing keys to a Client/Server.

Directions: This Program is best run on the command line. To use, simply unzip the files and do the following:
	1.) On one terminal, type: java -jar ServerEncryption.jar
	2.) On another terminal, type: java -jar ClientEncryption.jar

	The result will be that a .pem file is created with the encrypted phrase: SECURITY IS IMPORTANT.
